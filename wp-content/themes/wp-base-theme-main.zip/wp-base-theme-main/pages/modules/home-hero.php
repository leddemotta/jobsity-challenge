<?php
wp_enqueue_script('module-home_hero_js', get_stylesheet_directory_uri() . '/js/modules/home_hero.js', array('jquery'), _S_VERSION, true);
?>

<section class="home-hero">
  <h1>Home</h1>
</section>