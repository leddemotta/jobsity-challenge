<?php
/**
* Template Name: Home Page
*
* @package iwn_website
*/

get_header();

get_template_part('pages/modules/home', 'hero');

get_footer();