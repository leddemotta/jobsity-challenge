jQuery(document).ready(function ($) {
  console.log('Loaded home_hero.js');
});